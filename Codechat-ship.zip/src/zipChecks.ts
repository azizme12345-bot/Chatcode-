export interface StaticFact {
  level: 'ok' | 'problem' | 'warning';
  text: string;
}

interface PackageJsonLike {
  type?: string;
  scripts?: Record<string, string>;
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
}

interface LockFileLike {
  packages?: Record<
    string,
    { dependencies?: Record<string, string>; devDependencies?: Record<string, string> }
  >;
}

const LOCAL_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.css', '.json'];
const INDEX_EXTENSIONS = ['.ts', '.tsx', '.js', '.jsx'];
const CODE_FILE_RE = /\.(ts|tsx|js|jsx|mjs|cjs)$/i;
const IMPORT_RE =
  /(?:\bimport\b|\bexport\b)[^'"`;]*?\bfrom\s*['"]([^'"]+)['"]|\bimport\s*['"]([^'"]+)['"]|\bimport\(\s*['"]([^'"]+)['"]\s*\)/g;
const SCRIPT_TAG_RE = /<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi;
const API_CALL_RE = /['"`]\/api\/([A-Za-z0-9_\-/]+)['"`]/g;
const GOOGLE_KEY_RE = /AIza[0-9A-Za-z_-]{30,}/;

function normalizePath(path: string): string {
  const parts: string[] = [];
  for (const segment of path.split('/')) {
    if (!segment || segment === '.') continue;
    if (segment === '..') {
      parts.pop();
      continue;
    }
    parts.push(segment);
  }
  return parts.join('/');
}

function dirnameOf(path: string): string {
  const index = path.lastIndexOf('/');
  return index === -1 ? '' : path.slice(0, index);
}

function importCandidates(base: string): string[] {
  const candidates = [base];
  for (const ext of LOCAL_EXTENSIONS) candidates.push(base + ext);
  for (const ext of INDEX_EXTENSIONS) candidates.push(`${base}/index${ext}`);
  return candidates;
}

/**
 * Browser mein ZIP ke files par simple, pakki jaanch chalata hai.
 * Ye sirf wahi batata hai jo file ke text se saaf dikhta hai.
 * files: sirf text files ka map (path -> content)
 * allPaths: ZIP ki sabhi safe file paths (binary files bhi)
 */
export function runStaticChecks(files: Map<string, string>, allPaths: string[]): StaticFact[] {
  const facts: StaticFact[] = [];
  const pathSet = new Set(allPaths);

  // 1. package.json
  let pkg: PackageJsonLike | null = null;
  const pkgText = files.get('package.json');
  if (pkgText === undefined) {
    facts.push({ level: 'problem', text: 'package.json ZIP ke root (sabse upar) par nahi mili.' });
  } else {
    try {
      pkg = JSON.parse(pkgText) as PackageJsonLike;
      facts.push({ level: 'ok', text: 'package.json valid JSON hai.' });
    } catch {
      facts.push({ level: 'problem', text: 'package.json valid JSON nahi hai (syntax error).' });
    }
  }
  if (pkg) {
    if (pkg.scripts?.build) {
      facts.push({ level: 'ok', text: `package.json mein build script hai: "${pkg.scripts.build}".` });
    } else {
      facts.push({ level: 'warning', text: 'package.json mein "build" script nahi hai.' });
    }
  }

  // 2. package-lock.json aur package.json ka mel
  const lockText = files.get('package-lock.json');
  if (pkg && lockText !== undefined) {
    try {
      const lock = JSON.parse(lockText) as LockFileLike;
      const root = lock.packages?.[''];
      const declared: Record<string, string> = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
      const locked: Record<string, string> = { ...(root?.dependencies ?? {}), ...(root?.devDependencies ?? {}) };
      const mismatched = Object.keys(declared).filter((name) => locked[name] !== declared[name]);
      const extra = Object.keys(locked).filter((name) => !(name in declared));
      const problems = [...mismatched, ...extra];
      if (problems.length > 0) {
        facts.push({
          level: 'problem',
          text: `package-lock.json package.json se match nahi karti. Ye packages alag hain: ${problems.join(', ')}. Vercel par "npm ci" install fail ho sakta hai.`,
        });
      } else {
        facts.push({ level: 'ok', text: 'package-lock.json package.json se match karti hai.' });
      }
    } catch {
      facts.push({ level: 'problem', text: 'package-lock.json valid JSON nahi hai.' });
    }
  } else if (pkg) {
    facts.push({ level: 'warning', text: 'package-lock.json ZIP mein nahi hai.' });
  }

  // 3. index.html ke local script files
  const html = files.get('index.html');
  if (html === undefined) {
    facts.push({ level: 'problem', text: 'index.html ZIP ke root par nahi mili.' });
  } else {
    let scriptMatch: RegExpExecArray | null;
    SCRIPT_TAG_RE.lastIndex = 0;
    while ((scriptMatch = SCRIPT_TAG_RE.exec(html)) !== null) {
      const src = scriptMatch[1];
      if (/^https?:\/\//i.test(src)) continue;
      const path = normalizePath(src);
      if (pathSet.has(path)) {
        facts.push({ level: 'ok', text: `index.html ki script "${src}" ki file ZIP mein hai (${path}).` });
      } else {
        facts.push({
          level: 'problem',
          text: `index.html mein script "${src}" hai, lekin file "${path}" ZIP mein nahi hai.`,
        });
      }
    }
  }

  // 4. Code files ke local imports
  let checkedImports = 0;
  let brokenImports = 0;
  for (const codePath of allPaths.filter((p) => CODE_FILE_RE.test(p) && !p.endsWith('.d.ts'))) {
    const text = files.get(codePath);
    if (text === undefined) continue;
    IMPORT_RE.lastIndex = 0;
    let match: RegExpExecArray | null;
    while ((match = IMPORT_RE.exec(text)) !== null) {
      const spec = match[1] ?? match[2] ?? match[3];
      if (!spec) continue;
      let base: string;
      if (spec.startsWith('./') || spec.startsWith('../')) {
        base = normalizePath(`${dirnameOf(codePath)}/${spec}`);
      } else if (spec.startsWith('@/')) {
        base = normalizePath(spec.slice(2));
      } else {
        continue;
      }
      checkedImports += 1;
      if (!importCandidates(base).some((candidate) => pathSet.has(candidate))) {
        brokenImports += 1;
        facts.push({
          level: 'problem',
          text: `${codePath} mein import "${spec}" hai, lekin uski file ZIP mein nahi mili.`,
        });
      }
    }
  }
  if (checkedImports > 0 && brokenImports === 0) {
    facts.push({ level: 'ok', text: `${checkedImports} local imports ki jaanch hui, sab files mili.` });
  }

  // 5. Frontend se bulaye gaye /api/ routes
  const frontendPaths = allPaths.filter((p) => p.startsWith('src/') || p === 'index.html');
  for (const frontendPath of frontendPaths) {
    const text = files.get(frontendPath);
    if (text === undefined) continue;
    API_CALL_RE.lastIndex = 0;
    let apiMatch: RegExpExecArray | null;
    while ((apiMatch = API_CALL_RE.exec(text)) !== null) {
      const name = apiMatch[1].replace(/\/+$/, '');
      const candidates = [
        `api/${name}.js`,
        `api/${name}.ts`,
        `api/${name}/index.js`,
        `api/${name}/index.ts`,
      ];
      if (candidates.some((candidate) => pathSet.has(candidate))) {
        facts.push({ level: 'ok', text: `${frontendPath} "/api/${name}" call karta hai, aur api file ZIP mein hai.` });
      } else {
        facts.push({
          level: 'problem',
          text: `${frontendPath} "/api/${name}" call karta hai, lekin api/${name}.js ZIP mein nahi hai.`,
        });
      }
    }
  }

  // 6. Secret files aur keys
  for (const path of allPaths) {
    if (/(^|\/)\.env(\.|$)/i.test(path) && !path.endsWith('.env.example')) {
      facts.push({
        level: 'problem',
        text: `${path} file ZIP mein hai. Isme secret keys ho sakti hain, ise GitHub par nahi jana chahiye.`,
      });
    }
  }
  for (const path of allPaths) {
    const text = files.get(path);
    if (text !== undefined && GOOGLE_KEY_RE.test(text)) {
      facts.push({
        level: 'problem',
        text: `${path} mein Google API key jaisa text mila. Key code ke andar nahi honi chahiye.`,
      });
    }
  }
  for (const frontendPath of allPaths.filter((p) => p.startsWith('src/'))) {
    const text = files.get(frontendPath);
    if (text !== undefined && /process\.env\.GEMINI_API_KEY/.test(text)) {
      facts.push({
        level: 'problem',
        text: `${frontendPath} (browser code) mein process.env.GEMINI_API_KEY use hua hai. Browser mein key public ho sakti hai.`,
      });
    }
  }

  // 7. Server route key padhta hai ya nahi
  const apiGemini = files.get('api/gemini.js');
  if (apiGemini !== undefined && /process\.env\.GEMINI_API_KEY/.test(apiGemini)) {
    facts.push({ level: 'ok', text: 'api/gemini.js server par GEMINI_API_KEY environment variable se key padhta hai.' });
  }

  return facts;
}
